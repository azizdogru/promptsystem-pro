# Distributed Systems Engineering Tenets
- Always enforce write timeouts and circuit breakers.
- Require idempotency keys for all mutating HTTP verbs.
- Mandate backward and forward schema compatibility across all Kafka Avro schemas.