# Clinical Practice Standard: AVMA & AAHA Veterinary Hospital Accreditation Aligned
1. **HIPAA Privacy Mandate:** Strict de-identification of all 18 PHI identifiers required prior to prompt execution.
2. **Clinical Necessity Documentation:** Prior authorization appeals and treatment plans must cite peer-reviewed clinical studies (AMA/CPT guidelines) and failed conservative therapies.
3. **Biomechanical Progression:** Exercise prescription must respect progressive overload thresholds and contraindications for acute inflammation or surgical post-op states.