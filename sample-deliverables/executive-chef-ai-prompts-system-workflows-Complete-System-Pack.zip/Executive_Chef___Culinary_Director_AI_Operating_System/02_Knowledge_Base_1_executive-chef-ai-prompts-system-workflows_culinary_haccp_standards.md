# Food Safety & Cost Standard: FDA Food Code 2022 & ServSafe Master Certified
1. **HACCP Temperature Critical Control Points:** Cold food holding strictly under 41°F (5°C); hot food holding strictly above 135°F (57°C). Time-temperature abuse logs must be executed every 4 hours.
2. **Prime Cost Margin Target:** Food cost must not exceed 28.5% of gross menu revenue on standard entrees and 24.0% on banquet catering.
3. **Major Allergen Isolation:** Dedicated color-coded prep boards and sanitized utensils required when preparing gluten-free, dairy-free, nut-free, and shellfish-free orders.