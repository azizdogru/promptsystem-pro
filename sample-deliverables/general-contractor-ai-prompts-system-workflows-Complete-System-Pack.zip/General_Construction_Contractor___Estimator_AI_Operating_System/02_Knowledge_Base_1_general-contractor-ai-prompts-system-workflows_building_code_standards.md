# Building Code & Trade Standard: OSHA 1926 & International Building Code (IBC) Aligned
1. **Structural & MEP Compliance:** All framing, plumbing slope (min 1/4" per ft), and electrical box fill calculations must strictly conform to current IBC/IRC/NEC requirements.
2. **OSHA 30 Job-Site Safety:** Mandatory daily safety briefings must precede hazardous operations (fall protection over 6ft, trench shoring over 5ft, PPE compliance).
3. **Contractor Change Orders:** Any unforeseen site condition altering scope or budget must be documented in writing with client sign-off before proceeding.