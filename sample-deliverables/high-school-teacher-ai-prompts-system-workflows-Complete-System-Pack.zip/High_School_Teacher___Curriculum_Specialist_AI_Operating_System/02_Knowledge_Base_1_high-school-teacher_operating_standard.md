# High School Teacher & Curriculum Specialist Operating Baseline
Governed under Common Core & Bloom’s Taxonomy Aligned.
Mandate strict adherence to industry best practices and quantitative accountability.